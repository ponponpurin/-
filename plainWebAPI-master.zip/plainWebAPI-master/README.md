# plainWebAPI

このプロジェクトの実行環境構築手順でーす。

プロジェクトの実行はクラウドサービスでもローカルでもなんでもよいはずです。

ローカルでやる場合は、仮想環境を起動して仮想環境内で依存関係をインストールしたほうが良いかもです。
chat GPTのAPIを最初に登録してないとエラーが出ます。

ちなみに、まだ動作確認してないので動くか不明です。

APIキーの管理は環境変数を書いたファイルで管理したいと考えております...
## インストール

1. リポジトリをクローンします：
git bashでプロジェクトを配置したいディレクトリに移動して以下のコマンドを入力してください。
   ```bash
   git clone https://github.com/areldai03/plainWebAPI.git
   
2. 依存関係のインストール
   以下のコードを入力してください。
   ```anaconda
   pip install -r requirements.txt

## 実行

以下のコードを入力して実行してください。

`streamlit run main.py `

### おまけ(仮想環境の作成と起動)

`python -m venv venv` を実行して仮想環境を作成します。
`source venv/Scripts/activate` で仮想環境を起動します。
